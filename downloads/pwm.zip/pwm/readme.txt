First try to run PWM with the Attiny2313.
All four PWM-channels are used and changed in a loop resulting 4 connected LEDs being dimmed on and off. 